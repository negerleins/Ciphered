# Ciphered
A secure, end-to-end encrypted chat web application built with a React JSX frontend and a JavaScript backend.